# -*- coding: utf-8 -*-
"""
Created on Sun Apr 28 11:52:09 2019

@author: kpava
"""

import numpy as np
import matplotlib.pyplot as plt
from argparse import ArgumentParser
#yRange = 600
#xRange = 800

class Julia():
    def __init__(self,xRange,yRange):
        self.xRange = xRange
        self.yRange = yRange
    def InitialCalc(self,x,y):
        xRange = self.xRange
        yRange = self.yRange
        zx = 3 * (x-xRange/2) / xRange
        zy = 2 * (y-yRange/2) / yRange
        return[zx,zy]

    def WhileLoopCalc(self,zx,zy,i):
        a=zx**2-zy**2-0.7
        zy=2.0*zx*zy+0.27015
        zx=a
        i=i-1
        condition = zx**2 + zy**2
        return[condition, i, zx, zy]    
    def CalculateIntensity(self):
        xRange = self.xRange
        yRange = self.yRange
        A = np.zeros([yRange,xRange])
        for x in range(xRange):
            for y in range(yRange):
                [zx,zy] = self.InitialCalc(x,y)
                i=255
                condition = zx**2 + zy**2
                while condition < 4 and i > 1:
                    [condition, i, zx, zy] = self.WhileLoopCalc(zx,zy,i)
                A[y][x]=i
        plt.imshow(A)
        plt.savefig('test.png')
        plt.show()
        print('Finished!!')

if __name__ == '__main__':
    parser = ArgumentParser(description = 'Generate Julia function')
    parser.add_argument('xRange', type = int)
    parser.add_argument('yRange', type = int)
    arguments = parser.parse_args()    
    Julia(arguments.xRange,arguments.yRange).CalculateIntensity()
