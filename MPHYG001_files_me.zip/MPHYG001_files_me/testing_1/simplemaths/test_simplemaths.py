import pytest
from simplemaths.simplemaths import SimpleMaths as sm

class TestSimpleMaths():
    
    def testConstructorNeg(self):
        with pytest.raises(TypeError) as exception:
            sm(2.0)
    def test_square(self):
        assert sm(-2).square() == 4
        assert sm(0).square() == 0
        assert sm(1).square() == 1
        assert sm(3).square() == 9
    def test_factorial(self):
        assert sm(0).factorial() == 1
        assert sm(3).factorial() == 6
        assert sm(1).factorial() == 1
    def test_square_root(self):
        assert sm(0).square_root() == 0
        assert sm(-4).square_root() == pytest.approx(2j)
        assert sm(1).square_root() ==1
    def test_power(self):
        assert sm(0).power() == 0
        assert sm(-2).power() == -8
        assert sm(-2).power(4) == 16
        assert sm(4).power(0.5) == 2
        assert sm(5).power(-1) == 0.2
    def odd_or_even(self):
        assert sm(-4).odd_or_even() == 'Even'
        assert sm(-3).odd_or_even() == 'Odd'
        assert sm(0).odd_or_even() == 'Even'
        assert sm(1).odd_or_even() == 'Odd'
        assert sm(6).odd_or_even() == 'Even'
