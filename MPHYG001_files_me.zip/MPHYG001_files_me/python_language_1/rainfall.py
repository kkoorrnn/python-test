# -*- coding: utf-8 -*-
"""
Created on Sat Apr 27 19:02:59 2019

@author: Korn Pavavongsak
"""


import csv
import numpy as np
import json
from matplotlib import pyplot as plt


#Convert CSV file to appropriate dictionary format and save as json file
with open('python_language_1_data.csv','r') as file:
    DataCSV = list(csv.reader(file))

DataNP = np.array(DataCSV)                              #convert to numpy array
Dictionary = {str(x):[] for x in np.arange(1937,2013)}  #creating key for Dictionary
for data in DataNP[1:]:                                 #writing elements into key
    Dictionary[data[0]].append(float(data[2]))

with open('rainfallJData.json','w') as f:               #save as json file
    json.dump(Dictionary , f , indent = 4)
    

#drawing annual graph
def DrawAnnualGraph(filename,year,LineColour):
    with open(filename, 'r') as file:
        Data = json.load(file)
    
    figure = plt.plot(Data[str(year)], color = LineColour)
    plt.savefig(str(year) + '.png')
#Example function input: DrawAnnualGraph('rainfallJData.json', 1998, 'green')
    
    
#Drawing mean fall per year
def DrawMeanGraph(filename,startyear,endyear):
    with open(filename, 'r') as file:
        Data = json.load(file)
        
    xData = np.arange(startyear,endyear+1)
    yData =[np.array(Data[str(year)]).mean() for year in xData]
    figure = plt.plot(xData,yData)
    plt.savefig(str(startyear) + '_' + str(endyear)+'mean.png')
#Example function input: DrawMeanGraph('rainfallJData.json',1988,2000)


#Correcting data part
def Equation(value):
    result = value*1.2**0.5
    return(result)

def loopCorrected(year):
    correctedResult = []
    for days in Data[str(year)]:
        correctedResult.append(Equation(days))


def NoloopCorrected(year):
    correctedResult = [Equation(days) for days in Data[str(year)]]